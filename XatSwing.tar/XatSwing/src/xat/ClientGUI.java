/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package xat;

/**
 *
 * @author raquel
 */
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultListModel;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;

import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class ClientGUI{

    String      nomApp     = "Xat en Swing";
    ClientGUI   mainGUI;
    JFrame      novaFrame    = new JFrame(nomApp);
    JTextField  nickSeleccionat;
    JFrame      initialFrame;
    JTextArea   missatges;
    JScrollPane scrollMissatgesXat;
    JTextField  tfMissatge;
    JButton     btEnviar;
    JList       llista;
    DefaultListModel model;
    private boolean connectat = false;
    private MySocket socket;
    
    

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {
                    UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
                } catch (ClassNotFoundException | IllegalAccessException | InstantiationException | UnsupportedLookAndFeelException e) {
                }
                ClientGUI mainGUI = new ClientGUI();
                mainGUI.preDisplay();
            }
        });
    }
    
    public ClientGUI(){
        super();
        try {
            this.socket = new MySocket ("localhost", 5555);
        } catch (IOException ex) {
            Logger.getLogger(ClientGUI.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void preDisplay() {
        novaFrame.setVisible(false);
        initialFrame = new JFrame(nomApp);
        nickSeleccionat = new JTextField(15);
        nickSeleccionat.addActionListener(new enterServerButtonListener());
        JLabel triaUsuari = new JLabel("Introdueix l'usuari");
        JButton enterServer = new JButton("Entra al xat");
        enterServer.addActionListener(new enterServerButtonListener());
        JPanel panell = new JPanel(new GridBagLayout());
        nickSeleccionat.setSize(200,20);
        panell.add(triaUsuari);
        panell.add(nickSeleccionat);
        
        initialFrame.add(BorderLayout.CENTER, panell);
        initialFrame.add(BorderLayout.SOUTH, enterServer);
        initialFrame.setSize(300, 200);
        initialFrame.setLocationRelativeTo(null);
        initialFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        initialFrame.setVisible(true);

    }

    public void display() {
        missatges = new JTextArea();
        missatges.setEnabled(false); 
        missatges.setLineWrap(true); 
        missatges.setWrapStyleWord(true); 
        scrollMissatgesXat = new JScrollPane(missatges);
        tfMissatge = new JTextField("");
        tfMissatge.requestFocusInWindow();
        tfMissatge.addActionListener(new sendMessageButtonListener());
        btEnviar = new JButton("Enviar");
        btEnviar.setBackground(Color.BLUE);
        btEnviar.addActionListener(new sendMessageButtonListener());
        model = new DefaultListModel();
        llista = new JList(model);
        
        
        Container c = novaFrame.getContentPane();
        c.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.weightx = 1;
        gbc.weighty = 1;
        gbc.fill = GridBagConstraints.BOTH;
        c.add(scrollMissatgesXat, gbc);
        
        gbc.gridx = 2;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.weightx = 1;
        gbc.weighty = 1;
        gbc.fill = GridBagConstraints.BOTH;
        c.add(llista, gbc);
       
        gbc.gridwidth = 1;        
        gbc.weighty = 0;
        gbc.fill = GridBagConstraints.HORIZONTAL;        
        gbc.insets = new Insets(0, 10, 10, 10);
        gbc.gridx = 0;
        gbc.gridy = 1;
        c.add(tfMissatge, gbc);
        
        gbc.weightx = 0;
        gbc.gridx = 2;
        gbc.gridy = 1;
        gbc.anchor = GridBagConstraints.LINE_END;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        c.add(btEnviar, gbc);
        
        novaFrame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        novaFrame.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                socket.write(".desconectar");
                socket.close();
                novaFrame.dispose();
                System.exit(0);
            }
        });
        novaFrame.setSize(600, 500);
        novaFrame.setLocationRelativeTo(null);
        novaFrame.setVisible(true);
    }

    class sendMessageButtonListener implements ActionListener {
        public void actionPerformed(ActionEvent event) {
            if (tfMissatge.getText().length() < 1) {
                
            } else {
                missatges.append("<" + username + ">:  " + tfMissatge.getText()+ "\n");
                socket.write(tfMissatge.getText());
                tfMissatge.setText("");
            }
            tfMissatge.requestFocusInWindow();
        }
    }

    String  username;

    class enterServerButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent event) {
            username = nickSeleccionat.getText();
            
            if (username.length() < 1){
                
            }else{
                socket.write(username);
                if (socket.read().equals("NO")) {
                    JOptionPane.showMessageDialog(null, "El nick introduit ja existeix", "Error!", JOptionPane.INFORMATION_MESSAGE);
                    nickSeleccionat.setText("");
                } else {
                    initialFrame.setVisible(false);
                    connectat = true;
                    display();
                    OutputThread outThread = new OutputThread();
                    outThread.start();
                }
            }
        }
    }
    
    class OutputThread extends Thread{
        public void run(){
            while(connectat){
                String msg = socket.read();
                switch (msg) {
                    case ".desconectar":
                        connectat = false;
                        break;
                    case ".updateList":
                        actualitzarUsuaris();
                        break;
                    default:
                        missatges.append(msg + "\n");
                        break;
                }
            }
        }
    }
    public int close (){
        socket.close();
        novaFrame.dispose();
        return 0;
    }
    
    public void actualitzarUsuaris(){
        String u = socket.read();
        String [] l = u.split(" ");
        model.removeAllElements();
        for (String l1 : l) {
            model.addElement(l1);
        }
       
    }
}