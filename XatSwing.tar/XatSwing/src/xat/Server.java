/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package xat;

import java.io.*;
import java.net.*;
import java.util.concurrent.ConcurrentHashMap;


/**
 *
 * @author raquel
 */
public class Server {
    
    private MySocket socket;
    private MyServerSocket servidor;
    private ConcurrentHashMap<String, MySocket> mapa = new ConcurrentHashMap<>();
    private boolean b = true;
    
    public Server(int port){
        try{
            servidor = new MyServerSocket(port);
            while (true){
                Socket soc = servidor.accept();
                socket = new MySocket (soc);
                while (b){
                    String nick = socket.read();
                    if (mapa.containsKey(nick)){
                        socket.write("NO");
                    }else{
                        socket.write("OK");
                        mapa.put(nick, socket);
                        Thread fil = new ClientThread(mapa, nick);
                        fil.start();
                        b=false;
                    }
                }
                b=true;
            }
        }
        catch(IOException ioe){
            System.out.println(ioe); 
        }
    }
    
    public static void main(String args[]){
        Server servidor = new Server(5555);
    }
}
