/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package xat;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.io.IOException;

/**
 *
 * @author raquel
 */
public class ClientThread extends Thread{
    private String nick;
    private final ConcurrentHashMap<String,MySocket> mapa;
    private boolean connectat = true;
    
    public ClientThread (ConcurrentHashMap<String,MySocket> d , String nick) throws IOException{
        this.nick = nick;
        mapa = d;
    }
    public void darLista(){
        String list ="";
        for (Map.Entry<String,MySocket> entry : mapa.entrySet()){
            list =list + entry.getKey() + " ";
        }
        for (Map.Entry<String,MySocket> entry : mapa.entrySet()){
            entry.getValue().write(".updateList");
            entry.getValue().write(list);
        }
    }
    
    @Override
    public void run() {
        while (connectat){
            darLista();
            String linia = mapa.get(nick).read();
            if (linia.equals(".desconectar")) {
                connectat = false;
                mapa.get(nick).write(".desconectar");
                mapa.get(nick).close();
                mapa.remove(nick);
                darLista();
            }else{
                for (Map.Entry<String,MySocket> entry : mapa.entrySet()){
                    if (!entry.getKey().equals(nick)){
                        entry.getValue().write(nick + ": " + linia);
                    }
                }
            }
        }
    }
}
