/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package xat;

import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

/**
 *
 * @author raquel
 */


public class MySocket {
    private DataInputStream lector;
    private DataOutputStream escriptor;
    private Socket socket;
    
    public MySocket (String host, int port) throws IOException{
        socket = new Socket (host,port);
        lector = new DataInputStream(new BufferedInputStream(socket.getInputStream()));
        escriptor = new DataOutputStream(socket.getOutputStream());
    }
    
    public MySocket (Socket s){
        try {
            this.socket = s;
            lector = new DataInputStream(new BufferedInputStream(socket.getInputStream()));
            escriptor = new DataOutputStream(socket.getOutputStream());
        } catch (IOException ex) {
            Logger.getLogger(MySocket.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public Socket getSocket (){
        return this.socket;
    }
    
    public void setSocket (Socket socket){
        this.socket=socket;
    }
    
    public String read(){
        String linia = null;
        try {
            linia = lector.readUTF();
        } catch (IOException ex) {
            Logger.getLogger(MySocket.class.getName()).log(Level.SEVERE, null, ex);
        }
        return linia;
    }
    
    public void write(String string){
        try {
            escriptor.writeUTF(string);
            escriptor.flush();
        } catch (IOException ex) {
            Logger.getLogger(MySocket.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public void close (){
        try {
            lector.close();
            escriptor.close();
            socket.close();
        } catch (IOException ex) {
            Logger.getLogger(MySocket.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
